# External blood analysis plan fixed before effect estimation

Date 2026-09-27

The existing manuscript and the 2026-09-26 availability assessment select two blood modules for external evaluation: CXCL8_CXCR1_2 and Complement. Membership and the gene-standardisation approach are copied from the archived common.py. Other modules will not be substituted after viewing results.

## Primary independent dataset

GSE304872 is an external untreated early AIDP cohort with four patients and three retained healthy controls. Inspect the deposited Seurat object for cell-to-donor mapping, unintegrated raw counts, and cell labels before calculating group effects. If these are recoverable, sum monocyte counts per donor, require at least 20 monocytes per donor, compute log2(CPM + 0.5), standardise each nonconstant module gene across the seven donors, and average within each fixed module. The primary testing family comprises the two monocyte module comparisons, with BH adjustment. Use two-sided exact label permutation tests of mean differences, Hedges g, and HC3 mean-difference intervals. Report all results. Small-sample intervals and permutation granularity must remain visible in the statistical tables.

Monocytes are the primary target because the previously used single-cell blood cohort was analysed at this lineage. Use author cell annotations if available. Otherwise, assign broad lineages with the same marker-based workflow used for the original cohort, independently of diagnosis. Freeze annotation before comparing scores. If donor mapping or raw counts cannot be recovered, do not guess them and do not use cells as independent replicates.

Secondary observations, only where technically valid, include all-PBMC donor pseudobulk, monocyte subtypes, and donor cell proportions. Report these separately, correct additional tests within the complete displayed family, and do not add new subtype contrasts selectively. Do not pool multiple preparations from this cohort as independent studies.

GSE304871 contains sorted-cell bulk data from overlapping participants. Analyse the two fixed modules in CD11b cells (two patients and three controls), with CD4 and CD8 as descriptive supplementary results. Use log2(deposited normalised counts + 0.5) and the same gene standardisation. Correct the six module-by-preparation tests together. This is complementary measurement within one cohort, not an additional independent cohort.

## Additional Brazilian PBMC dataset

PRJNA1174992 has public counts and clinical labels, but independence from GSE211225 and inconsistent source collection dates remain unresolved. Analyse it separately without adding it to the primary meta-analysis. Aggregate the 87 technical columns to 25 biological samples before normalisation. Primary external reanalysis uses T0 (12 patients) versus CTR (five controls), with normalisation and gene standardisation fitted to these 17 participants only. Apply the original median-ratio normalisation and log2(normalised count + 0.5), requiring at least two nonconstant genes per module. Correct the two module tests together. Report HC3 intervals, exact mean-difference permutation tests, and Hedges g.

Prespecified sensitivities are CPM normalisation and age-plus-sex adjustment. The eight paired T0/T1 samples form a separate longitudinal comparison. Normalise the 16 samples together, standardise across paired samples, test within-patient changes by all 256 sign assignments, and correct the two module tests together. No unpaired replication claim is made for the follow-up samples. RIN is available, but treatment timing and batch details must be assessed before interpretation.

## Integration and writing

Preserve the original three-cohort blood meta-analysis. Report newly examined cohorts as external extensions, including discordant or nonsignificant findings. A new independent four-cohort sensitivity synthesis is permissible only if donor independence and compatible monocyte measurements are established; do not replace the original result or include the Brazilian candidate as fully independent before resolving overlap.

Retain the existing external nerve analysis and its cell-composition interpretation. No new cross-disease validation claims are planned. Update abstract, results, discussion, methods, source catalogue, references, supplementary material and figure source data to match completed analyses. Preserve evidence strength and record data-source limitations once in the appropriate section.
