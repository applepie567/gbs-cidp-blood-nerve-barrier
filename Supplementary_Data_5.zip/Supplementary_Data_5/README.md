# Supplementary Data 5 External blood analyses

Analysis date: 2026-09-27. This package accompanies the updated manuscript and has not been deposited as a new Zenodo release. The original v2.4.0 archive remains a frozen earlier analysis.

## What was tested

Two gene sets were retained without changing membership after examining new effects: CXCL8/CXCR1/CXCR2 and the original 18-gene complement set. The plan was recorded before effect estimation. The primary independent comparison is GSE304872 author-annotated monocytes from four early AIDP patients and three controls. Each donor is one observation. This analysis uses the unintegrated RNA counts, not corrected expression or individual cells as replicates. Complement scoring uses the 15 available genes.

Primary effects: CXCL8 g=0.708532, exact P=0.342857, q=0.342857; complement g=0.881971, exact P=0.228571, q=0.342857. These are positive external estimates with wide intervals. Whole PBMCs and monocyte subclusters reuse the same donors and form a separate ten-test family. GSE304871 sorted CD11b/CD4/CD8 profiles overlap this cohort and use a six-test family. The deposited gene-name fields were inconsistent with Ensembl row identifiers, so the fixed targets were mapped through GENCODE v38. The original inputs and annotation audit are retained.

PRJNA1174992 contains 12 acute samples, eight paired follow-up samples and five controls. Its 87 technical columns were collapsed to 25 biological samples. Its independence from GSE211225 is unresolved; it is analysed separately and excluded from the four-cohort sensitivity synthesis. The acute comparison has negative CXCL8 and positive complement estimates, both q=0.438914. The eight paired samples show an increase in the CXCL8 score at follow up (q=0.015625), with unresolved technical and collection-time effects. This is not evidence of a treatment mechanism or validation of an acute disease marker.

## Reproduce the statistical tables

Use Python with numpy, pandas, scipy and matplotlib; the versions used are in `software_versions.json`. From this directory run:

```bash
python scripts/analyse_external_blood.py all
python scripts/make_external_figures.py
```

All inputs needed for these commands are included. The supplied donor pseudobulk counts contain all 16,164 deposited genes. CPM denominators are computed from all of these genes. The plotting command writes regenerated figures to `outputs/Figures/`. The distributed review figures are also in `Figures/`.

The authoritative adjusted tests are `results/GSE304872_all_effects.csv`, `results/GSE304871_sorted_bulk_effects.csv`, `results/Brazil_T0_median_ratio_effects.csv`, `results/Brazil_paired_effects.csv`, and `results/targeted_four_cohort_meta.csv`. Per-population intermediate effect tables omit q values when adjustment spans several populations. HC3 intervals and exact permutation tests use different procedures and should not be treated as mathematical equivalents. The targeted four-cohort synthesis is secondary and preserves the original three-cohort results.

## Repeat extraction from the public Seurat object

This optional step needs about 4 GB for the source RDS and roughly 11 GB of temporary disk space, plus rdata 1.1.0 and xarray. It is unnecessary for rerunning statistics from the included donor counts.

```bash
python scripts/download_full_seurat.py
python scripts/stream_rds.py
python scripts/rds_utils.py
python scripts/extract_external_pseudobulk.py
python scripts/analyse_external_blood.py all
```

The streaming parser writes large numerical arrays to disk without changing them. It extracts the author sample and condition labels and verifies barcode alignment and nonnegative integer counts. The raw object is not included in this package. `source_manifest.csv` records its URL, exact size and SHA-256 checksum, alongside those of the public bulk inputs and GENCODE source.

## Files and provenance

- `inputs/`: original public count tables, clinical/technical mappings and the frozen GENCODE annotation subset.
- `results/`: donor counts, cell metadata, gene coverage, normalisation factors within score tables, all module and fraction tests, and targeted synthesis.
- `scripts/`: extraction, analysis and plotting code. The base R script independently checks the primary scores and exact tests. Run `Rscript scripts/verify_primary.R` from this directory; its recorded output is `primary_R_verification.txt`.
- `ANALYSIS_PLAN.md`: plan recorded before new disease effects were calculated.
- `Figure_source_index.csv`: exact data files behind each new panel.

GSE304871/2 source: O’Brien et al., bioRxiv, https://doi.org/10.1101/2025.09.24.678413 (preprint). PRJNA1174992 source: Negreiros Neto et al., Scientific Reports, https://doi.org/10.1038/s41598-026-71564-5. GENCODE release 38: https://www.gencodegenes.org/human/release_38.html. The public source files retain their original attribution and terms; newly written analysis code is provided under the MIT licence. No credentials or private reviewer access links are included.
