# Editorial audit before manuscript revision

The new analyses require changes to claims, not just added result lists.

- Abstract and opening Discussion: distinguish the original three-cohort recurrence from positive but imprecise external monocyte estimates; introduce the opposing whole-PBMC CXCL8 direction.
- Results: add a connected external-testing section after the original blood synthesis; retain the complete negative and nonsignificant results in the supplement.
- Interpretation: discuss a cell-population-dependent observation, without claiming the PBMC contrast proves a compositional mechanism.
- Brazilian PBMC data: report separately because overlap with GSE211225 is unresolved; the paired finding is a follow-up association and cannot identify a treatment or recovery mechanism.
- Methods: specify author Monocyte labels, donor aggregation, unavailable complement genes, independent gene-ID remapping of sorted bulk counts, two primary tests and all secondary families.
- References and figures: insert external source papers, renumber references by first appearance, introduce external blood Figure 3, move the former CSF and nerve figures to Figures 4 and 5. Keep old statistical values unchanged.
- Data statement: identify Supplementary Data 5 as a new package; do not claim it is already deposited under the frozen v2.4.0 DOI.
- Editing: preserve the existing scientific style, remove generic recurrence claims, use direct explanations, and highlight changed text in yellow.
