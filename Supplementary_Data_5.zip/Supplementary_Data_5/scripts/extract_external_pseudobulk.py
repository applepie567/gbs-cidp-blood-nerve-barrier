"""Recover raw RNA counts and author metadata from the deposited Seurat object.
No integrated or scaled values contribute to pseudobulk expression.
"""
from pathlib import Path
import numpy as np,pandas as pd,json
from scipy import sparse
from rds_utils import tree,attrs,named,scalar,ROOT

t=tree();root=attrs(t.object);rna=attrs(named(root['assays'])['RNA']);counts=attrs(named(rna['layers'])['counts'])
for k in ['cells','features']:
 a=attrs(rna[k]);print(k,list(a),flush=True)
 if 'dimnames' in a:
  print('dimnames types',[(v.info.type,len(v.value) if isinstance(v.value,list) else None) for v in a['dimnames'].value],flush=True)
md=pd.read_csv(ROOT/'results/GSE304872_cell_metadata.csv',index_col=0,dtype={'sample':str,'seurat_clusters':str})
cellnames=scalar(attrs(rna['cells'])['dimnames'].value[0]); genes=scalar(attrs(rna['features'])['dimnames'].value[0])
print('n cells',len(cellnames),'n genes',len(genes),'count dims',scalar(counts['Dim']),flush=True)
assert list(md.index)==cellnames
assert len(genes)==len(set(genes))
for n in ['cells','features']:
 a=rna[n];dims=scalar(attrs(a)['dim']);layers=scalar(attrs(a)['dimnames'].value[1]);values=np.asarray(a.value).reshape(dims,order='F')
 assert values[:,layers.index('counts')].all(),n
mat=sparse.csc_matrix((scalar(counts['x']),scalar(counts['i']),scalar(counts['p'])),shape=tuple(scalar(counts['Dim'])),copy=False)
assert np.diff(mat.indptr).min()>0
# The deposited assay contains a filtered gene set. Use the complete deposited
# counts layer for CPM denominators rather than the earlier nCount_RNA values.
sums=np.add.reduceat(mat.data,mat.indptr[:-1]);assert (sums>0).all() and np.all(sums<=md.nCount_RNA+1e-8)
audit=pd.DataFrame({'barcode':md.index,'count_layer_sum':sums,'metadata_nCount_RNA':md.nCount_RNA.to_numpy()})
audit['fraction_retained']=audit.count_layer_sum/audit.metadata_nCount_RNA
audit.describe().to_csv(ROOT/'results/GSE304872_count_layer_audit.csv')
for i in range(0,len(mat.data),1000000):
 a=mat.data[i:i+1000000];assert (a>=0).all() and np.isfinite(a).all() and np.equal(a,np.floor(a)).all()
print(pd.crosstab(md['sample'],md.condition),flush=True)
print(pd.crosstab(md['broad.cluster'],md.seurat_clusters).to_string(),flush=True)
# Freeze author lineage annotation and report all eligible monocyte subclusters.
mono_clusters=sorted(md.loc[md['broad.cluster'].eq('Monocyte'),'seurat_clusters'].unique(),key=int)
annotation={'primary':'broad.cluster == Monocyte','monocyte_clusters':mono_clusters,'PMA':'separate author population; excluded from primary Monocyte','secondary':['all_PBMC']+[f'Monocyte_cluster_{k}' for k in mono_clusters],'threshold':20,'scope':'two primary tests; all secondary module tests as one family'}
(ROOT/'results/GSE304872_annotation_rule.json').write_text(json.dumps(annotation,indent=2))

labels=md['sample']+'|'+md['broad.cluster'];unique=list(dict.fromkeys(labels));codes=pd.Categorical(labels,categories=unique).codes
design=sparse.csr_matrix((np.ones(len(md)),(np.arange(len(md)),codes)),shape=(len(md),len(unique)))
pb=pd.DataFrame((mat@design).toarray(),index=genes,columns=unique)
for sample in sorted(md['sample'].unique()):
 pb[sample+'|all_PBMC']=pb.filter(regex='^'+sample+r'\|').sum(axis=1)
mask=md['broad.cluster'].eq('Monocyte').to_numpy();sub=md.loc[mask]
labels2=sub['sample']+'|Monocyte_cluster_'+sub.seurat_clusters;u2=list(dict.fromkeys(labels2));c2=pd.Categorical(labels2,categories=u2).codes
d2=sparse.csr_matrix((np.ones(len(sub)),(np.flatnonzero(mask),c2)),shape=(len(md),len(u2)))
p2=pd.DataFrame((mat@d2).toarray(),index=genes,columns=u2);pb=pd.concat([pb,p2],axis=1).round().astype('int64')
metadata=[]
for col in pb:
 sample,group=col.split('|');select=md['sample'].eq(sample)
 if group.startswith('Monocyte_cluster_'):select &= md['broad.cluster'].eq('Monocyte') & md.seurat_clusters.eq(group.split('_')[-1])
 elif group!='all_PBMC':select &= md['broad.cluster'].eq(group)
 v=md[select];assert len(v.condition.unique())==1
 metadata.append(dict(pseudobulk_id=col,donor_id='Sample_'+sample,source_sample=sample,compartment=group,diagnosis=v.condition.iloc[0],cells=len(v),library_counts=int(pb[col].sum())))
pbm=pd.DataFrame(metadata);pb.to_csv(ROOT/'results/GSE304872_pseudobulk_counts.csv.gz',index_label='gene');pbm.to_csv(ROOT/'results/GSE304872_pseudobulk_metadata.csv',index=False)
fr=pd.crosstab(md['sample'],md['broad.cluster']);fr.to_csv(ROOT/'results/GSE304872_cell_counts.csv',index_label='source_sample')
print('EXTRACTED',pb.shape,flush=True)
