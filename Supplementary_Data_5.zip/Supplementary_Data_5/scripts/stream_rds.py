"""Read the public RDS without materialising its full numeric payload in RAM.
Uses rdata 1.1.0 parsing; numeric arrays are disk backed, with no transformations.
"""
from pathlib import Path
import sys,gzip,numpy as np,pickle,time,json
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'runtime/python'))
from rdata.parser._parser import Parser
D=ROOT/'runtime/rds_arrays';D.mkdir(parents=True,exist_ok=True)
class Stream(Parser):
 def __init__(self,f):super().__init__();self.file=f;self.k=0
 def _parse_array_values(self,dtype,length):
  dtype=np.dtype(dtype);n=int(length)*dtype.itemsize
  if n<2000000:
   b=self.file.read(n)
   if len(b)!=n:raise EOFError((len(b),n))
   return np.frombuffer(b,dtype=dtype.newbyteorder('>')).astype(dtype,copy=True)
  self.k+=1;p=D/f'array_{self.k:03d}.npy';print(self.k,dtype,length,round(n/1e6,1),'MB',flush=True)
  a=np.lib.format.open_memmap(p,mode='w+',dtype=dtype,shape=(length,))
  chunk=1024*1024
  for i in range(0,length,chunk):
   m=min(chunk,length-i);b=self.file.read(m*dtype.itemsize)
   if len(b)!=m*dtype.itemsize:raise EOFError()
   a[i:i+m]=np.frombuffer(b,dtype=dtype.newbyteorder('>'))
  a.flush();return a
 def parse_string(self,length):return self.file.read(length)
 def parse_nullable_int_array(self,**kw):return self._parse_array(np.int32)
class DiskPickler(pickle.Pickler):
 def persistent_id(self,obj):
  if isinstance(obj,np.memmap):return ('memmap',str(obj.filename))
  return None
with gzip.open(ROOT/'input/GSE304872_Processed_Data_Seurat.rds','rb') as f:
 assert f.read(2)==b'X\n'
 x=Stream(f).parse_all()
with open(ROOT/'runtime/seurat_tree.pkl','wb') as f:DiskPickler(f,protocol=5).dump(x)
print('Saved tree',flush=True)
