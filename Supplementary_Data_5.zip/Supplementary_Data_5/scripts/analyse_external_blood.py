"""Fixed-module external blood reanalysis. Biological samples are the units.
Run from a package root containing inputs/, results/ and this scripts/ folder.
The working layout also accepts input/ and audit/ directories.
"""
from pathlib import Path
import itertools, math, json, gzip, re
import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'results'; OUT.mkdir(exist_ok=True)
MODULES = {
    'CXCL8_CXCR1_2':['CXCL8','CXCR1','CXCR2'],
    'Complement':['C1QA','C1QB','C1QC','C2','C3','C4A','C4B','C5','CFB','CFD','CFH','CFI','SERPING1','C3AR1','C5AR1','CR1','CD55','CD59']}

def locate(name):
    for d in ['inputs','input','audit','audit/sources','audit/public_files','results']:
        p=ROOT/d/name
        if p.exists(): return p
    raise FileNotFoundError(name)

def bh(p):
    p=np.asarray(p,float); o=np.argsort(p); q=np.empty(len(p))
    q[o]=np.minimum.accumulate((p[o]*len(p)/np.arange(1,len(p)+1))[::-1])[::-1]
    return np.clip(q,0,1)

def scores(expr):
    sd=expr.std(axis=1,ddof=1); z=expr.sub(expr.mean(axis=1),axis=0).div(sd.replace(0,np.nan),axis=0)
    result={}; cov=[]
    for module,genes in MODULES.items():
        valid=[g for g in genes if g in z.index and np.isfinite(z.loc[g]).all()]
        if len(valid)<2: raise ValueError((module,valid))
        result[module]=z.loc[valid].mean(axis=0)
        cov.extend({'module':module,'gene':g,'present':g in expr.index,'variable':g in valid} for g in genes)
    return pd.DataFrame(result),pd.DataFrame(cov),z.loc[z.index.intersection(sum(MODULES.values(),[]))]

def median_ratio(x):
    complete=(x>0).all(axis=1)
    if complete.sum()>=100:
        geo=np.exp(np.log(x.loc[complete]).mean(axis=1))
        sf=x.loc[complete].div(geo,axis=0).median(axis=0)
        method='median_ratio'
    else:
        sf=x.sum(axis=0)/x.sum(axis=0).median();method='library_sum_fallback'
    sf=sf/np.exp(np.log(sf).mean())
    return x.div(sf,axis=1),sf,method

def hc3(y,case,extra=None):
    y=np.asarray(y,float);x=np.column_stack([np.ones(len(y)),np.asarray(case,float)])
    if extra is not None: x=np.column_stack([x,np.asarray(extra,float)])
    assert np.linalg.matrix_rank(x)==x.shape[1]
    inv=np.linalg.inv(x.T@x);b=inv@x.T@y;e=y-x@b
    h=np.sum((x@inv)*x,axis=1)
    cov=inv@(x.T@(((e/(1-h))**2)[:,None]*x))@inv
    se=float(np.sqrt(cov[1,1]));df=len(y)-x.shape[1];c=stats.t.ppf(.975,df)
    return dict(delta=float(b[1]),ci_low=float(b[1]-c*se),ci_high=float(b[1]+c*se),hc3_se=se,hc3_df=df,model_p=float(2*stats.t.sf(abs(b[1]/se),df)))

def compare(s,case):
    y=np.asarray(s,float);case=np.asarray(case,bool);a=y[case];b=y[~case];n=len(a);m=len(b)
    obs=a.mean()-b.mean();nperm=math.comb(n+m,n)
    total=y.sum();ext=0
    for ix in itertools.combinations(range(n+m),n):
        asum=y[list(ix)].sum();d=asum/n-(total-asum)/m
        ext+=abs(d)>=abs(obs)-1e-12
    sp=np.sqrt(((n-1)*a.var(ddof=1)+(m-1)*b.var(ddof=1))/(n+m-2))
    return dict(n_case=n,n_control=m,mean_case=a.mean(),mean_control=b.mean(),hedges_g=(1-3/(4*(n+m)-9))*obs/sp,exact_p=ext/nperm,permutations=nperm,**hc3(y,case))

def evaluate(expr,meta,prefix,condition='case',write_q=True):
    ss,coverage,z=scores(expr);ss=meta.join(ss);ss.to_csv(OUT/f'{prefix}_scores.csv',index_label='sample_id')
    coverage.to_csv(OUT/f'{prefix}_coverage.csv',index=False);z.to_csv(OUT/f'{prefix}_gene_z.csv',index_label='gene')
    rows=[dict(module=k,**compare(ss[k],ss[condition])) for k in MODULES]
    res=pd.DataFrame(rows)
    if write_q:res['q']=bh(res.exact_p)
    res.to_csv(OUT/f'{prefix}_effects.csv',index=False)
    return ss,res

def brazil():
    meta=pd.read_csv(locate('PRJNA1174992_sample_mapping.csv'),dtype={'patient_id':str}).set_index('sample_id')
    raw=pd.read_csv(locate('new_GBS_supp13.csv'),sep=';',index_col=0)
    assert raw.shape[1]==87 and np.isfinite(raw.to_numpy()).all() and (raw.to_numpy()>=0).all()
    raw=raw.groupby(level=0,sort=False).sum()
    used=[c for s in meta.count_matrix_columns for c in s.split(';')]
    assert len(used)==len(set(used))==87 and set(used)==set(raw.columns)
    x=pd.DataFrame({s:raw[m.count_matrix_columns.split(';')].sum(axis=1) for s,m in meta.iterrows()})
    assert np.allclose(x.sum().sum(),raw.sum().sum())
    x.to_csv(OUT/'PRJNA1174992_biological_counts.csv.gz',index_label='gene')
    cross=meta.loc[meta.condition.isin(['T0','CTR'])].copy();cross['case']=cross.condition.eq('T0')
    norm,sf,method=median_ratio(x[cross.index]);cross['size_factor']=sf;cross['total_counts']=x[cross.index].sum();cross['normalisation']=method
    ss,res=evaluate(np.log2(norm+.5),cross,'Brazil_T0_median_ratio')
    cpm=x[cross.index].div(x[cross.index].sum(),axis=1)*1e6
    _,res_cpm=evaluate(np.log2(cpm+.5),cross,'Brazil_T0_CPM')
    adj=[]
    extra=np.column_stack([pd.to_numeric(cross.age_as_reported),cross.sex.eq('Male').astype(int)])
    for k in MODULES:adj.append(dict(module=k,**hc3(ss[k],ss.case,extra)))
    ad=pd.DataFrame(adj);ad['q_model']=bh(ad.model_p);ad.to_csv(OUT/'Brazil_T0_age_sex.csv',index=False)
    ids=meta.loc[meta.condition.eq('T1'),'patient_id'].tolist()
    pair=meta.loc[meta.patient_id.isin(ids)&meta.condition.isin(['T0','T1'])].copy()
    assert pair.groupby('patient_id').size().eq(2).all() and len(pair)==16
    norm,sf,method=median_ratio(x[pair.index]);ps,cov,z=scores(np.log2(norm+.5));ps=pair.join(ps);ps['size_factor']=sf
    ps.to_csv(OUT/'Brazil_paired_scores.csv',index_label='sample_id');cov.to_csv(OUT/'Brazil_paired_coverage.csv',index=False)
    pr=[]
    for k in MODULES:
        v=ps.pivot(index='patient_id',columns='condition',values=k);diff=v.T1-v.T0
        signs=np.array(list(itertools.product([-1,1],repeat=len(diff))))
        p=float(np.mean(np.abs(signs@diff.to_numpy()/len(diff))>=abs(diff.mean())-1e-12))
        se=stats.sem(diff);c=stats.t.ppf(.975,len(diff)-1)
        pr.append(dict(module=k,n_pairs=len(diff),delta_T1_minus_T0=diff.mean(),ci_low=diff.mean()-c*se,ci_high=diff.mean()+c*se,paired_dz=diff.mean()/diff.std(ddof=1),exact_p=p,assignments=len(signs)))
    pr=pd.DataFrame(pr);pr['q']=bh(pr.exact_p);pr.to_csv(OUT/'Brazil_paired_effects.csv',index=False)
    print('BRAZIL',res.to_string(index=False),'\nPAIRED',pr.to_string(index=False),sep='\n',flush=True)

def gencode_map():
    cached=ROOT/'inputs/gencode_v38_module_mapping.csv'
    if cached.exists():
        d=pd.read_csv(cached);d.to_csv(OUT/'gencode_v38_module_mapping.csv',index=False);return d
    target=set(sum(MODULES.values(),[]));rows=[]
    with gzip.open(locate('gencode.v38.annotation.gtf.gz'),'rt') as f:
        for line in f:
            if line.startswith('#'):continue
            col=line.split('\t')
            if col[2]!='gene':continue
            at=dict(re.findall(r'(\w+) "([^"]+)"',col[8]))
            if at.get('gene_name') in target:
                rows.append(dict(gene_id=at['gene_id'],ensembl_gene_id=at['gene_id'].split('.')[0],symbol=at['gene_name'],chromosome=col[0]))
    d=pd.DataFrame(rows).drop_duplicates();d.to_csv(OUT/'gencode_v38_module_mapping.csv',index=False);return d

def sorted_bulk():
    mapping=gencode_map();meta=pd.read_csv(locate('GSE304871_sample_mapping.csv')).set_index('library_name')
    allrows=[];checks=[]
    for prep in ['CD11b','CD4','CD8']:
        x=pd.read_csv(locate(f'GSE304871_{prep}_normalized_counts.csv.gz'),index_col=0)
        m=meta.loc[meta.cell_preparation.eq(prep)].copy();m['case']=m.diagnosis.eq('GBS')
        ids=x.index.str.split('.').str[0];sym=dict(zip(mapping.ensembl_gene_id,mapping.symbol))
        keep=ids.isin(sym); expr=x.loc[keep,m.index].copy();expr.index=ids[keep].map(sym);expr=expr.groupby(level=0,sort=False).sum()
        for eid in x.index[keep]:
            checks.append(dict(preparation=prep,row_ensembl_id=eid,verified_symbol=sym[eid.split('.')[0]],deposited_gene_name=x.loc[eid,'gene_name']))
        expr.to_csv(OUT/f'GSE304871_{prep}_mapped_counts.csv',index_label='gene')
        ss,res=evaluate(np.log2(expr+.5),m,f'GSE304871_{prep}',write_q=False);res['preparation']=prep;allrows.append(res)
    out=pd.concat(allrows,ignore_index=True);out['q_six_tests']=bh(out.exact_p)
    out.to_csv(OUT/'GSE304871_sorted_bulk_effects.csv',index=False);pd.DataFrame(checks).to_csv(OUT/'GSE304871_annotation_audit.csv',index=False)
    print('SORTED BULK',out.to_string(index=False),sep='\n',flush=True)

def singlecell():
    x=pd.read_csv(locate('GSE304872_pseudobulk_counts.csv.gz'),index_col=0)
    meta=pd.read_csv(locate('GSE304872_pseudobulk_metadata.csv')).set_index('pseudobulk_id')
    rule=json.loads(locate('GSE304872_annotation_rule.json').read_text())
    primary=['Monocyte']; secondary=rule['secondary'];resall=[]
    for group in primary+secondary:
        m=meta.loc[meta.compartment.eq(group)&meta.cells.ge(20)].copy();m['case']=m.diagnosis.eq('GBS')
        if m.case.sum()<3 or (~m.case).sum()<3:
            raise ValueError(('prespecified group not eligible',group,m))
        y=x[m.index].div(x[m.index].sum(),axis=1)*1e6
        ss,res=evaluate(np.log2(y+.5),m,'GSE304872_'+group,write_q=False)
        res['compartment']=group;res['family']='primary' if group in primary else 'secondary';resall.append(res)
    out=pd.concat(resall,ignore_index=True)
    for family in ['primary','secondary']:
        mask=out.family.eq(family);out.loc[mask,'q']=bh(out.loc[mask,'exact_p'])
    out.to_csv(OUT/'GSE304872_all_effects.csv',index=False)
    # Fractions describe the representation of author cell categories in the retained cells.
    fr=pd.read_csv(locate('GSE304872_cell_counts.csv'),index_col=0);fractions=fr.div(fr.sum(axis=1),axis=0)
    dm=meta.loc[meta.compartment.eq('all_PBMC')].set_index('source_sample');dm.index=dm.index.astype(str);fractions.index=fractions.index.astype(str)
    rr=[]
    for group in fractions:
        rr.append(dict(compartment=group,**compare(fractions[group],dm.loc[fractions.index,'diagnosis'].eq('GBS'))))
    frres=pd.DataFrame(rr);frres['q']=bh(frres.exact_p);frres.to_csv(OUT/'GSE304872_fraction_effects.csv',index=False);fractions.to_csv(OUT/'GSE304872_cell_fractions.csv',index_label='source_sample')
    print('SINGLE CELL',out.to_string(index=False),sep='\n',flush=True)

def extended_meta():
    def meta(g,v):
        g=np.array(g,float);v=np.array(v,float);k=len(g);w=1/v;m=np.average(g,weights=w);Q=np.sum(w*(g-m)**2)
        tau=max(0,(Q-k+1)/(w.sum()-(w*w).sum()/w.sum()));wr=1/(v+tau);est=np.average(g,weights=wr)
        se=np.sqrt(max(1,np.sum(wr*(g-est)**2)/(k-1))/wr.sum());c=stats.t.ppf(.975,k-1)*se
        return dict(k=k,hedges_g=est,ci_low=est-c,ci_high=est+c,p=2*stats.t.sf(abs(est/se),k-1),tau2=tau,I2=max(0,(Q-k+1)/Q)*100 if Q>0 else 0)
    old=pd.read_csv(locate('Blood_cohort_effects_original.csv'));expected=pd.read_csv(locate('Blood_meta_original.csv')).set_index('Program')
    new=pd.read_csv(OUT/'GSE304872_all_effects.csv');res=[];inputs=[]
    for k,name in [('CXCL8_CXCR1_2','CXCL8–CXCR1/2'),('Complement','Complement')]:
        b=old.loc[old.Program.eq(name)];m=meta(b['Hedges g'],b.Variance)
        np.testing.assert_allclose([m['hedges_g'],m['ci_low'],m['ci_high'],m['p']],expected.loc[name,['Summary Hedges g','95% CI low','95% CI high','Hartung–Knapp P']].to_numpy(dtype=float),atol=1e-7)
        n=new.loc[new.module.eq(k)&new.compartment.eq('Monocyte')].iloc[0];var=(n.n_case+n.n_control)/(n.n_case*n.n_control)+n.hedges_g**2/(2*(n.n_case+n.n_control-2))
        vals=list(b['Hedges g'])+[n.hedges_g];vs=list(b.Variance)+[var]
        res.extend([dict(module=k,analysis='original_three',**m),dict(module=k,analysis='targeted_four',**meta(vals,vs))])
        inputs.extend(dict(module=k,cohort=c,g=g,variance=v) for c,g,v in zip(list(b.Cohort)+['GSE304872 monocytes'],vals,vs))
    out=pd.DataFrame(res);out['q_two_targeted_tests']=np.nan;mask=out.analysis.eq('targeted_four');out.loc[mask,'q_two_targeted_tests']=bh(out.loc[mask,'p'])
    out.to_csv(OUT/'targeted_four_cohort_meta.csv',index=False);pd.DataFrame(inputs).to_csv(OUT/'targeted_four_cohort_inputs.csv',index=False)
    print('META',out.to_string(index=False),sep='\n',flush=True)

if __name__=='__main__':
    import sys
    mode=sys.argv[1] if len(sys.argv)>1 else 'all'
    if mode in ['all','brazil']:brazil()
    if mode in ['all','sorted']:sorted_bulk()
    if mode in ['all','singlecell']:singlecell()
    if mode in ['all','meta']:extended_meta()
