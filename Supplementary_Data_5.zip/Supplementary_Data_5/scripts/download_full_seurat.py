"""Download the ordinary public GEO file and verify its frozen checksum."""
from pathlib import Path
import csv,hashlib,urllib.request
ROOT=Path(__file__).resolve().parents[1]
name='GSE304872_Processed_Data_Seurat.rds'
with (ROOT/'source_manifest.csv').open() as f:
    row=next(r for r in csv.DictReader(f) if r['file']==name)
target=ROOT/'input'/name;target.parent.mkdir(exist_ok=True)
if not target.exists():
    with urllib.request.urlopen(row['public_source'],timeout=120) as src,target.open('wb') as dst:
        while block:=src.read(1024*1024):dst.write(block)
h=hashlib.sha256()
with target.open('rb') as f:
    while block:=f.read(1024*1024):h.update(block)
assert target.stat().st_size==int(row['bytes'])
assert h.hexdigest()==row['sha256']
print('Verified',target)
