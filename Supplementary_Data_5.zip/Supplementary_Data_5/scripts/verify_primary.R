x<-read.csv(gzfile('results/GSE304872_pseudobulk_counts.csv.gz'),row.names=1,check.names=FALSE)
m<-read.csv('results/GSE304872_pseudobulk_metadata.csv',check.names=FALSE)
m<-m[m$compartment=='Monocyte',];x<-as.matrix(x[,m$pseudobulk_id]);e<-log2(sweep(x,2,colSums(x),'/')*1e6+.5)
sets<-list(CXCL8_CXCR1_2=c('CXCL8','CXCR1','CXCR2'),Complement=c('C1QA','C1QB','C1QC','C2','C3','C4A','C4B','C5','CFB','CFD','CFH','CFI','SERPING1','C3AR1','C5AR1','CR1','CD55','CD59'))
ps<-read.csv('results/GSE304872_Monocyte_scores.csv',check.names=FALSE)
pe<-read.csv('results/GSE304872_all_effects.csv');pe<-pe[pe$compartment=='Monocyte',]
for(k in names(sets)){
 g<-intersect(sets[[k]],rownames(e));z<-t(scale(t(e[g,,drop=FALSE])));s<-colMeans(z,na.rm=TRUE);stopifnot(max(abs(s-ps[[k]]))<1e-12)
 d<-mean(s[m$diagnosis=='GBS'])-mean(s[m$diagnosis=='Control']);p<-mean(combn(seq_along(s),4,FUN=function(i) abs(mean(s[i])-mean(s[-i]))>=abs(d)-1e-12));stopifnot(abs(p-pe$exact_p[pe$module==k])<1e-12)
 cat(k,': independent R score and exact test match; p =',p,'\n')
}
