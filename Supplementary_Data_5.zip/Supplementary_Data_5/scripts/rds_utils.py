from pathlib import Path
import sys,pickle,numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'runtime/python'))
from rdata.parser._parser import RObjectType
import rdata
class DiskUnpickler(pickle.Unpickler):
 def persistent_load(self,pid):
  kind,path=pid;assert kind=='memmap';return np.load(path,mmap_mode='r')
def tree():
 with open(ROOT/'runtime/seurat_tree.pkl','rb') as f:return DiskUnpickler(f).load()
def deref(x):
 while x and x.referenced_object is not None:x=x.referenced_object
 return x
def scalar(x):
 x=deref(x)
 if x.info.type==RObjectType.SYM:return scalar(x.value)
 if x.info.type==RObjectType.CHAR:return x.value.decode() if x.value else None
 if x.info.type==RObjectType.STR:return [scalar(v) for v in x.value]
 return x.value
def attrs(x):
 p=deref(x).attributes;d={}
 while p is not None:
  p=deref(p)
  if p.info.type in (RObjectType.NIL,RObjectType.NILVALUE):break
  d[scalar(p.tag)]=p.value[0];p=p.value[1]
 return d
def named(x):
 x=deref(x);names=scalar(attrs(x)['names']);return dict(zip(names,x.value))
if __name__=='__main__':
 t=tree();a=attrs(t.object);print('slots',list(a))
 md=rdata.conversion.convert(a['meta.data']);print(md.shape,md.columns.tolist());md.to_csv(ROOT/'results/GSE304872_cell_metadata.csv',index_label='barcode')
 for k in md:
  if md[k].nunique()<100:print(k,md[k].value_counts(dropna=False).to_dict())
 ass=named(a['assays']);print('ASSAYS',list(ass))
 for k,x in ass.items():
  aa=attrs(x);print(k,list(aa))
  if 'layers' in aa:
   for n,y in named(aa['layers']).items():print('LAYER',n,y.info.type,'attrs',list(attrs(y)), 'dim',scalar(attrs(y).get('Dim')) if 'Dim' in attrs(y) else 'array')
 print('ident',scalar(attrs(a['active.ident']).get('levels')))
