"""Render figures from the frozen donor scores and complete effect tables."""
from pathlib import Path
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

ROOT=Path(__file__).resolve().parents[1];D=ROOT/'results';O=ROOT/'outputs/Figures';O.mkdir(parents=True,exist_ok=True)
BLUE='#32688E';ORANGE='#C4652F';GREY='#6B7280';TEAL='#287E80'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.titlesize':10,'axes.labelsize':9,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'svg.fonttype':'none','savefig.facecolor':'white'})
MODULES=['CXCL8_CXCR1_2','Complement'];NAMES=['CXCL8 recruitment','Complement']
def save(fig,name):
 for ext in ['png','pdf','svg']:fig.savefig(O/f'{name}.{ext}',dpi=350,bbox_inches='tight',pad_inches=.12)
 plt.close(fig)
def panel(ax,letter,title):
 ax.set_title(title,loc='left',pad=28,fontweight='bold');ax.text(-.16,1.15,letter,transform=ax.transAxes,fontweight='bold',fontsize=13)
def scatter(ax,s,k,r,groups,labels):
 for j,(group,label,col) in enumerate(zip(groups,labels,[ORANGE,BLUE])):
  y=s.loc[s.group.eq(group),k].to_numpy();x=j+np.linspace(-.10,.10,len(y));ax.scatter(x,y,s=32,color=col,edgecolor='white',linewidth=.45,zorder=3)
  ax.plot([j-.19,j+.19],[y.mean()]*2,color='black',lw=1.2)
 ax.set_xticks([0,1],labels);ax.set_xlim(-.5,1.5);ax.set_ylabel('Mean standardised expression');ax.grid(axis='y',alpha=.16,zorder=0)
 ax.text(0,1.015,f"g = {r.hedges_g:.2f}; exact P = {r.exact_p:.3f}; q = {r.q:.3f}",transform=ax.transAxes,fontsize=8.2)
def figure3():
 e=pd.read_csv(D/'GSE304872_all_effects.csv');fig,axes=plt.subplots(2,2,figsize=(7.6,6.4));fig.subplots_adjust(wspace=.45,hspace=.72)
 for row,group in enumerate(['Monocyte','all_PBMC']):
  s=pd.read_csv(D/f'GSE304872_{group}_scores.csv');s['group']=s.diagnosis
  for c,k in enumerate(MODULES):
   r=e.loc[e.compartment.eq(group)&e.module.eq(k)].iloc[0];ax=axes[row,c]
   panel(ax,'ABCD'[row*2+c],('Monocytes' if row==0 else 'All PBMCs')+' · '+NAMES[c]);scatter(ax,s,k,r,['GBS','Control'],['GBS\n(n = 4)','Control\n(n = 3)'])
 save(fig,'Figure_3')
def forest(ax,rows,labels,color):
 y=np.arange(len(rows));ax.axvline(0,color='#999999',lw=.8,ls='--');ax.errorbar(rows.delta,y,xerr=np.vstack([rows.delta-rows.ci_low,rows.ci_high-rows.delta]),fmt='o',color=color,lw=1,ms=4,capsize=2)
 ax.set_yticks(y,labels);ax.invert_yaxis();ax.set_xlabel('GBS − control mean score (95% CI)');ax.grid(axis='x',alpha=.13)
def s10():
 e=pd.read_csv(D/'GSE304872_all_effects.csv');b=pd.read_csv(D/'GSE304871_sorted_bulk_effects.csv');fig,axes=plt.subplots(2,2,figsize=(8.3,6.2));fig.subplots_adjust(left=.21,right=.98,wspace=.72,hspace=.68)
 clusters=['3','6','9','13'];labels=['Classical (3)','Intermediate (6)','Activated\nintermediate (9)','Nonclassical (13)']
 for c,k in enumerate(MODULES):
  a=e.loc[e.module.eq(k)&e.compartment.str.startswith('Monocyte_cluster')].copy();a['order']=a.compartment.map({f'Monocyte_cluster_{n}':i for i,n in enumerate(clusters)});a=a.sort_values('order')
  panel(axes[0,c],'AB'[c],NAMES[c]+' · monocyte clusters');forest(axes[0,c],a,labels,BLUE)
  a=b.loc[b.module.eq(k)];panel(axes[1,c],'CD'[c],NAMES[c]+' · sorted cells');forest(axes[1,c],a,['CD11b (2, 3)','CD4 (3, 3)','CD8 (2, 3)'],TEAL)
 save(fig,'Supplementary_Figure_10')
def s11():
 s=pd.read_csv(D/'Brazil_T0_median_ratio_scores.csv');s['group']=s.condition;e=pd.read_csv(D/'Brazil_T0_median_ratio_effects.csv');ps=pd.read_csv(D/'Brazil_paired_scores.csv');pe=pd.read_csv(D/'Brazil_paired_effects.csv')
 fig,axes=plt.subplots(2,2,figsize=(7.6,6.4));fig.subplots_adjust(wspace=.44,hspace=.75)
 for c,k in enumerate(MODULES):
  panel(axes[0,c],'AB'[c],NAMES[c]+' · acute comparison');scatter(axes[0,c],s,k,e.loc[e.module.eq(k)].iloc[0],['T0','CTR'],['Acute GBS\n(n = 12)','Control\n(n = 5)'])
  ax=axes[1,c];panel(ax,'CD'[c],NAMES[c]+' · paired follow up')
  v=ps.pivot(index='patient_id',columns='condition',values=k)
  for _,r in v.iterrows():ax.plot([0,1],[r.T0,r.T1],color='#C1C5CA',lw=.85,zorder=1)
  for j,g in enumerate(['T0','T1']):ax.scatter(np.repeat(j,len(v)),v[g],s=29,color=[ORANGE,BLUE][j],edgecolor='white',lw=.45,zorder=3)
  r=pe.loc[pe.module.eq(k)].iloc[0];ax.text(0,1.015,f"Paired Δ = {r.delta_T1_minus_T0:.2f}; exact P = {r.exact_p:.3f}; q = {r.q:.3f}",transform=ax.transAxes,fontsize=8.1)
  ax.set_xticks([0,1],['Acute (T0)','Follow up (T1)']);ax.set_xlim(-.35,1.35);ax.set_ylabel('Mean standardised expression');ax.grid(axis='y',alpha=.16)
 save(fig,'Supplementary_Figure_11')
def figure1():
 fig=plt.figure(figsize=(8.2,3.3));ax=fig.add_axes([0,0,1,1]);ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off')
 ax.text(.5,.965,'Recurrence across cohorts and cellular interpretation',ha='center',va='top',fontsize=13,weight='bold')
 cards=[(.018,BLUE,'Blood','Do the signals recur in new\npatients and cell populations?',
 'Discovery: 3 GBS blood cohorts\nExternal monocytes: 4 GBS, 3 controls\nSame cohort: PBMCs and sorted cells\nAdditional PBMC reanalysis: 12 GBS, 5 controls'),
 (.35,TEAL,'Cerebrospinal fluid','Do published proteins show\nrelated immune changes?',
 '2 independent protein cohorts\n11 paired GBS protein estimates\n16 direct disease comparison estimates\nSource tests and pooled uncertainty'),
 (.682,ORANGE,'Peripheral nerve','How does cell composition\naffect Fc expression?',
 'Atlas: 9 CIDP and 11 CIAP donors\nMacrophage states and Fc expression\nExternal nerve: 4 CIDP, 9 VN\nInternal comparator: 9 CIDP, 5 VN')]
 for x,col,title,question,body in cards:
  ax.add_patch(FancyBboxPatch((x,.04),.30,.79,boxstyle='round,pad=0.008,rounding_size=.012',fc='#F6F8FA',ec='#D2DAE1',lw=.8))
  ax.add_patch(FancyBboxPatch((x,.67),.30,.16,boxstyle='round,pad=0.008,rounding_size=.012',fc=col,ec=col))
  ax.text(x+.15,.75,title,ha='center',va='center',color='white',fontsize=12,weight='bold')
  ax.text(x+.15,.56,question,ha='center',va='center',fontsize=9,weight='bold',linespacing=1.35)
  ax.text(x+.15,.275,body,ha='center',va='center',fontsize=7.5,linespacing=2.2)
 save(fig,'Figure_1')
if __name__=='__main__':figure1();figure3();s10();s11()
