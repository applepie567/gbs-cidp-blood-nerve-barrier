# External cohort analysis plan

Recorded 26 September 2026 before inspecting candidate gene values or disease contrasts in the newly acquired expression matrix. This is a dated analysis plan, not a preregistration. Existing manuscript results were already known.

## Blood cohort

Target OEP002315 and OEP002701. Verify repository access, count matrices, sample tag to donor mapping, diagnosis, disease phase, treatment and independence from the three manuscript cohorts before analysis. Use peak AIDP versus healthy controls as the primary contrast; recovery samples are descriptive. Preserve the original CXCL8_CXCR1_2 and Complement gene lists. Aggregate monocyte counts by donor, require at least 20 cells per donor, use log2(CPM + 0.5), standardise each varying gene across eligible donors, and average available genes. Report gene coverage, Hedges g, exact two-sided label permutation P values and BH correction across the two selected modules. These targets were selected from earlier results, before viewing the new cohort. A blocked download is an access limitation, not a validation result. Do not substitute cell-level tests for donor-level tests or count these two accessions automatically as two cohorts.

## External nerve cohort

GSE213455 comprises four inflammatory-neuropathy samples identified as CIDP in the associated article, nine vasculitic-neuropathy samples and three lymphomatous-neuropathy samples. Verify this mapping using sample metadata and the article before testing. The primary external contrast is CIDP versus vasculitic neuropathy. Exclude lymphomatous neuropathy from scoring and testing. This is an exploratory test of transfer across a different disease comparator and whole-tissue assay, not direct replication of the original macrophage-specific CIDP versus CIAP contrast.

Use the 11 genes measured in the original Fc score: FCGR1A, FCGR2A, FCGR2B, FCGR3A, FCGR3B, FCGRT, FCER1G, TYROBP, SYK, LYN and HCK. Exclude FCGR2C to preserve the original measured gene set. Use deposited quantile-normalised log-scale expression values without re-logging. Map probes with GPL13369 annotation. Use probes with one unambiguous gene symbol and collapse multiple probes per gene by median. No selection by disease effect, P value or correlation is allowed. Score each gene by its mean and sample standard deviation across the 13 eligible donors, then average varying genes. Require at least eight of the 11 genes for a module-level comparison. Retain and report all coverage failures.

Primary statistic is the CIDP minus vasculitic-neuropathy mean score difference. Report exact two-sided Mann-Whitney P, Hedges g and an unadjusted HC3 mean-difference interval using residual t degrees of freedom. There is one prespecified external module comparison, selected following the original exploratory analysis, so report P without portraying it as confirmatory evidence. Gene-level tests form a separate BH family over all eligible Fc genes. Sensitivity analyses are an age-and-sex-adjusted HC3 model, alternate mean probe aggregation and leave-one-donor-out direction. No post hoc expansion to unrelated pathways.

If the original donor-level nerve expression can be recovered, make the same CIDP versus vasculitic-neuropathy comparison in the original macrophage data as a clearly labelled post hoc comparator check. Do not pool whole-tissue and macrophage-specific estimates or claim cellular replication from bulk nerve data.

## Reporting

Record available and inaccessible candidates and report all completed results, including disagreement. Preserve existing results and correction families. Any new figures and tables must identify dataset, comparator and statistical unit. Data access and updated analyses remain local until a new public release is explicitly made.

## Comparator-check implementation addendum

Recorded after the external GSE213455 result was calculated but before examining Fc expression in the recovered original VN donors. Public metadata show nine CIDP donors and five VN donors in GSE285983. All 14 are male, and all five VN donors are from Würzburg. Reconstruct the original Macro1 plus Macro2 score from CellBender counts using the 11 fixed genes, a minimum of 20 nuclei per donor, whole-library CPM and sample-standard-deviation scaling across all eligible atlas donors. Verify the reconstructed CIDP versus CIAP mean difference against the archived −0.672867 result before interpreting the new comparator check. Compare CIDP versus VN with an exact two-sided rank test and an unadjusted HC3 interval. Report age-and-centre adjustment and a Würzburg-only comparison as sensitivities. Do not fit sex because all 14 donors are male. This check is post hoc and uses the discovery atlas, so it is not additional independent validation. The external cohort result and its frozen primary test remain unchanged.
