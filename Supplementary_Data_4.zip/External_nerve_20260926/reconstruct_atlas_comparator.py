#!/usr/bin/env python3
"""Reconstruct the published atlas Fc score, then check CIDP versus VN.

Requires GEO GSE285983_RAW.tar and GSE285983_metadata_all.csv.gz in inputs/.
Source files are public and intentionally excluded from the compact package.
"""
import argparse
import gc
import hashlib
import io
import json
import re
import tarfile
from pathlib import Path

from hdf_reader import read_cellbender
import numpy as np
import pandas as pd
from scipy import sparse, stats

from analyse_external_nerve import GENES, hc3, exact_rank_p, hedges_g, score_frame


def main(root):
    out=root/'results'
    out.mkdir(exist_ok=True,parents=True)
    counts_path=out/'GSE285983_macrophage_Fc_counts.csv'
    metadata_path=root/'inputs/GSE285983_metadata_all.csv.gz'
    archive_path=root/'inputs/GSE285983_RAW.tar'
    if not counts_path.exists():
        meta=pd.read_csv(metadata_path,usecols=['sample','barcode','cluster','level2','age','sex','center'])
        donor=meta[['sample','level2','age','sex','center']].drop_duplicates().set_index('sample')
        assert len(donor)==37
        mac=meta[meta.cluster.isin(['Macro1','Macro2'])]
        rows=[]
        with tarfile.open(archive_path) as archive:
            for member in archive:
                if not member.isfile() or not member.name.endswith('.h5'): continue
                sample=re.search(r'_(S\d+)_',member.name).group(1)
                sample_meta=donor.loc[sample]
                bc=set(mac.loc[mac['sample']==sample,'barcode'].str.removeprefix(sample+'_'))
                raw=archive.extractfile(member).read()
                if True:
                    m=read_cellbender(raw)
                    names=[x.decode() for x in m['features/name'][:]]
                    barcode=[x.decode() for x in m['barcodes'][:]]
                    selected=np.array([i for i,b in enumerate(barcode) if b in bc])
                    assert len(selected)==len(bc)
                    assert all(g in names for g in GENES)
                    c=sparse.csc_matrix((m['data'][:],m['indices'][:],m['indptr'][:]),shape=tuple(m['shape'][:]))
                    selected_counts=c[:,selected]
                    library=float(selected_counts.sum())
                    gene_counts=np.asarray(selected_counts[[names.index(g) for g in GENES]].sum(axis=1)).ravel()
                    row=dict(sample_id=sample,diagnosis=sample_meta.level2,age=int(sample_meta.age),sex=sample_meta.sex,
                             centre=sample_meta.center,n_nuclei=len(selected),library_counts=library,eligible=len(selected)>=20,
                             h5_filename=member.name,h5_sha256=hashlib.sha256(raw).hexdigest())
                    row.update(dict(zip(GENES,gene_counts)))
                    rows.append(row)
                    print(sample,sample_meta.level2,len(selected),'macrophage nuclei',flush=True)
                    del c,selected_counts
                del raw
                gc.collect()
        pd.DataFrame(rows).sort_values('sample_id').to_csv(counts_path,index=False)
    donor=pd.read_csv(counts_path).set_index('sample_id')
    donor=donor[donor.eligible]
    assert len(donor)==37
    expr=np.log2(donor[GENES].div(donor.library_counts,axis=0)*1e6+0.5)
    expr.to_csv(out/'GSE285983_macrophage_Fc_log2CPM.csv')
    score=score_frame(expr)
    donor['Fc_score']=score
    donor[['diagnosis','age','sex','centre','n_nuclei','library_counts','Fc_score']].to_csv(out/'GSE285983_macrophage_Fc_scores.csv')
    delta=float(score[donor.diagnosis=='CIDP'].mean()-score[donor.diagnosis=='CIAP'].mean())
    assert abs(delta-(-0.672867))<1e-6, f'Original score mismatch: {delta}'
    replication_check=dict(original_CIDP_minus_CIAP=delta,
                           archived_rounded_difference=-0.672867,
                           absolute_difference_from_rounded_archive=abs(delta+0.672867),
                           scipy_asymptotic_p=float(stats.mannwhitneyu(score[donor.diagnosis=='CIDP'],score[donor.diagnosis=='CIAP']).pvalue))
    selected=donor[donor.diagnosis.isin(['CIDP','VN'])]
    assert len(selected)==14 and (selected.sex=='male').all()
    y=selected.Fc_score.to_numpy()
    d=(selected.diagnosis=='CIDP').to_numpy().astype(int)
    base=hc3(y,d)
    base.update(model='Atlas CIDP versus VN',n_CIDP=int(d.sum()),n_VN=int((1-d).sum()),p_exact_rank=exact_rank_p(y,d)[0],hedges_g=hedges_g(y,d))
    covariates=[(selected.age-selected.age.mean()).to_numpy()]
    covariates += [(selected.centre==x).to_numpy().astype(int) for x in ['Essen','Würzburg']]
    adj=hc3(y,d,covariates)
    adj.update(model='Atlas age and centre adjusted',n_CIDP=int(d.sum()),n_VN=int((1-d).sum()))
    within=selected[selected.centre=='Würzburg']
    dw=(within.diagnosis=='CIDP').to_numpy().astype(int)
    same=hc3(within.Fc_score.to_numpy(),dw)
    same.update(model='Atlas Würzburg only',n_CIDP=int(dw.sum()),n_VN=int((1-dw).sum()),p_exact_rank=exact_rank_p(within.Fc_score.to_numpy(),dw)[0],hedges_g=hedges_g(within.Fc_score.to_numpy(),dw))
    pd.DataFrame([base,adj,same]).to_csv(out/'Atlas_CIDP_VN_results.csv',index=False)
    changes=[]
    for gene in GENES:
        changes.append(dict(gene=gene,mean_CIDP=float(expr.loc[donor.diagnosis=='CIDP',gene].mean()),
                            mean_VN=float(expr.loc[donor.diagnosis=='VN',gene].mean()),
                            difference_CIDP_minus_VN=float(expr.loc[donor.diagnosis=='CIDP',gene].mean()-expr.loc[donor.diagnosis=='VN',gene].mean())))
    pd.DataFrame(changes).to_csv(out/'Atlas_CIDP_VN_gene_directions.csv',index=False)
    summary=dict(reconstruction_check=replication_check,primary=base,adjusted=adj,within_centre=same,
                 n_atlas_donors=len(donor),normalisation='log2(CPM + 0.5), 11 gene z scores across 37 eligible atlas donors (ddof=1)',
                 all_VN_same_centre=True,interpretation='post hoc internal comparator check, not independent validation')
    (out/'atlas_comparator_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
    print(json.dumps(summary,indent=2),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    main(p.parse_args().root)
