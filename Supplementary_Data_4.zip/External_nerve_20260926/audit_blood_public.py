"""Reproduce the public blood supplement inventory without redistributing hospital IDs.

Downloads the publisher's public supplementary package via Europe PMC.
NODE access is assessed as an ordinary unauthenticated request; no login or
access restriction is bypassed. Count data are never inferred from enrichment.
"""
from pathlib import Path
import argparse
import io
import json
import urllib.request
import urllib.error
import zipfile
import pandas as pd


def main(root):
    inputs=root/'inputs';inputs.mkdir(exist_ok=True,parents=True)
    results=root/'results';results.mkdir(exist_ok=True,parents=True)
    checks=[]
    for accession in ['OEP002315','OEP002701']:
        url='https://www.biosino.org/node/project/detail/'+accession
        try:
            with urllib.request.urlopen(url,timeout=30) as r:
                checks.append(dict(accession=accession,url=url,http_status=r.status))
        except urllib.error.HTTPError as e:checks.append(dict(accession=accession,url=url,http_status=e.code))
        except Exception as e:checks.append(dict(accession=accession,url=url,error=str(e)))
    (results/'NODE_access_check.json').write_text(json.dumps(checks,indent=2))
    url='https://www.ebi.ac.uk/europepmc/webservices/rest/PMC10088807/supplementaryFiles'
    path=inputs/'PMC10088807_supplementary.zip'
    if not path.exists():
        with urllib.request.urlopen(url,timeout=60) as r:path.write_bytes(r.read())
    inventory=[]
    with zipfile.ZipFile(path) as z:
        for name in z.namelist():
            if 'MOESM' not in name or not name.endswith(('.xls','.xlsx')):continue
            x=pd.ExcelFile(io.BytesIO(z.read(name)))
            for sheet in x.sheet_names:
                d=pd.read_excel(x,sheet_name=sheet)
                inventory.append(dict(file=name,sheet=sheet,rows=len(d),columns=len(d.columns),column_names=list(map(str,d.columns))))
            if name.endswith('MOESM4_ESM.xlsx'):
                d=pd.read_excel(x)
                s=d[d.iloc[:,0].astype(str).str.fullmatch('[TC][1-5]')]
                clean=pd.DataFrame({'published_sample_code':s.iloc[:,0],'age':s.iloc[:,1],
                                    'sex':s.iloc[:,2],'disease_phase':s.iloc[:,7].fillna('Healthy control'),
                                    'diagnosis':s.iloc[:,11].fillna('Healthy control')})
                clean['candidate_primary_comparison']=clean.disease_phase.isin(['Peak Stage','Healthy control'])
                clean['source']='Li et al. 2023 Supplementary Table 1, doi:10.1038/s41598-023-32427-5'
                clean.to_csv(results/'Blood_candidate_public_sample_summary.csv',index=False)
    (results/'blood_supplement_inventory.json').write_text(json.dumps(inventory,indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    main(p.parse_args().root)
