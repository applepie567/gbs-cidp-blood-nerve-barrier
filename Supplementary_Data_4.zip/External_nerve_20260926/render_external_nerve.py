#!/usr/bin/env python3
"""Render Supplementary Figure S9 from the complete saved results."""
from pathlib import Path
import argparse
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import MultipleLocator

BLUE='#2878A8'
ORANGE='#D98939'
GREY='#777777'


def main(root,out):
    out.mkdir(parents=True,exist_ok=True)
    results=root/'results'
    ext=pd.read_csv(results/'Fc_donor_scores.csv')
    atlas=pd.read_csv(results/'GSE285983_macrophage_Fc_scores.csv')
    atlas=atlas[atlas.diagnosis.isin(['CIDP','VN'])]
    efit=pd.read_csv(results/'Fc_module_results.csv')
    afit=pd.read_csv(results/'Atlas_CIDP_VN_results.csv')
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.titlesize':9,
                         'axes.labelsize':8,'pdf.fonttype':42,'svg.fonttype':'none'})
    fig,ax=plt.subplots(2,2,figsize=(7.7,6.3),gridspec_kw={'width_ratios':[1,1.28]})
    fig.subplots_adjust(left=.10,right=.97,bottom=.12,top=.88,wspace=.49,hspace=.75)
    rng=np.random.default_rng(20260926)
    for a,d,title,letter,p in [(ax[0,0],ext,'Independent whole nerve\nGSE213455','A',efit.iloc[0].p_exact_rank),
                              (ax[1,0],atlas,'Atlas macrophages\nGSE285983','C',afit.iloc[0].p_exact_rank)]:
        for i,(group,color) in enumerate([('CIDP',BLUE),('VN',ORANGE)]):
            y=d.loc[d.diagnosis==group,'Fc_score'].to_numpy()
            x=i+rng.uniform(-.13,.13,len(y))
            a.scatter(x,y,s=29,c=color,edgecolors='white',linewidths=.45,zorder=3)
            a.plot([i-.22,i+.22],[y.mean(),y.mean()],c='black',lw=1.3,zorder=4)
        a.set_xticks([0,1],[f'CIDP\n(n = {(d.diagnosis=="CIDP").sum()})',f'Vasculitic neuropathy\n(n = {(d.diagnosis=="VN").sum()})'])
        a.set_xlim(-.5,1.55); a.set_ylabel('Fc module score')
        a.set_title(title,pad=11)
        a.text(.5,.97,f'Exact P = {p:.3f}',ha='center',va='top',transform=a.transAxes,fontsize=8)
        a.set_ylim(min(d.Fc_score)-.18,max(d.Fc_score)+.45)
        a.text(-.22,1.20,letter,transform=a.transAxes,weight='bold',fontsize=12)
    for a,fit,labels,title,letter in [
        (ax[0,1],efit,['Median probes\n(primary)','Age and sex\nadjusted','Mean probes'], 'External cohort estimates','B'),
        (ax[1,1],afit,['Unadjusted','Age and centre\nadjusted','Würzburg only'], 'Internal comparator checks','D')]:
        for i,row in fit.iterrows():
            a.errorbar(row.difference,2-i,xerr=[[row.difference-row.ci_low],[row.ci_high-row.difference]],
                       fmt='o',color=BLUE if i==0 else GREY,ms=5,capsize=3,lw=1.15)
        a.axvline(0,color='#B6B6B6',lw=.8,ls='--')
        a.set_yticks([2,1,0],labels)
        a.set_ylim(-.55,2.55)
        a.set_xlabel('CIDP − vasculitic neuropathy\nMean score difference (95% CI)')
        a.set_title(title,pad=11)
        a.text(-.38,1.20,letter,transform=a.transAxes,weight='bold',fontsize=12)
        a.set_xlim(min(fit.ci_low)-.10,max(fit.ci_high)+.14)
        a.xaxis.set_major_locator(MultipleLocator(.5))
    for a in ax.flat:
        a.spines[['top','right']].set_visible(False)
        a.tick_params(length=3,width=.6)
        a.spines[['left','bottom']].set_linewidth(.6)
    fig.legend(handles=[Line2D([0],[0],marker='o',lw=0,color=BLUE,label='CIDP (A, C)'),
                        Line2D([0],[0],marker='o',lw=0,color=ORANGE,label='Vasculitic neuropathy (A, C)'),
                        Line2D([0],[0],color='black',lw=1.3,label='Group mean (A, C)')],
               loc='upper center',bbox_to_anchor=(.5,1.0),ncol=3,frameon=False,fontsize=7.8)
    fig.text(.10,.025,'B, D: blue = unadjusted comparison; grey = sensitivity analysis. Score scales are specific to each cohort.',fontsize=7.2)
    for extension in ['png','pdf','svg']:
        fig.savefig(out/f'Supplementary_Figure_9.{extension}',dpi=400)
    plt.close(fig)
    ext.to_csv(results/'Figure_S9A_external_donors.csv',index=False)
    efit.to_csv(results/'Figure_S9B_external_models.csv',index=False)
    atlas.to_csv(results/'Figure_S9C_atlas_donors.csv',index=False)
    afit.to_csv(results/'Figure_S9D_atlas_models.csv',index=False)


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    p.add_argument('--output',type=Path)
    args=p.parse_args()
    main(args.root,args.output or args.root/'figures')
