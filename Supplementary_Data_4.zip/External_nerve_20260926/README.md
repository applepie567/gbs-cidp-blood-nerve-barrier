# External nerve analysis, 26 September 2026

This package adds a targeted external Fc score comparison to the inflammatory neuropathy manuscript. It is a manuscript update, not a new Zenodo or GitHub release.

## Results and scope

- GSE213455: four CIDP and nine vasculitic neuropathy sural nerve biopsies. Three neurolymphomatosis biopsies were excluded before scoring. All 11 fixed genes were represented by 18 annotated probes.
- Primary external mean score difference: −0.836553, HC3 95% CI −1.763592 to 0.090486, Hedges g −1.196820, exact rank P = 0.075524. The primary analysis used median probe aggregation. Age and sex adjustment, mean probe aggregation and all donor omissions retained negative directions.
- Mean probe aggregation gave exact rank P = 0.050350 and model P = 0.045813. Its model interval excluded zero, whereas the primary interval did not. These are reported separately, without replacing the frozen primary test.
- No external Fc gene rank test passed BH correction across 11 genes. The smallest q was 0.061538 for FCGR1A.
- The original GSE285983 score was reconstructed from all 37 source matrices. The CIDP versus CIAP difference was −0.672867173 and the original asymptotic rank P was 0.001087437, matching the archived result.
- A subsequent internal CIDP versus vasculitic neuropathy check gave −0.533088, exact P = 0.028971. All five vasculitic neuropathy donors came from Würzburg. Age and centre adjustment gave model P = 0.124469, and the Würzburg-only exact P was 0.142857.

The external and internal estimates agree in direction. The independent cohort measures whole nerve and uses a different comparator from the original macrophage CIDP versus CIAP contrast. It does not establish cell-specific replication. The internal comparator check reuses the discovery atlas and is not a second validation cohort.

NODE accessions OEP002315 and OEP002701 remain candidates for independent blood testing. The public clinical supplement identifies three peak AIDP cases, two late cases and three healthy controls. Project pages returned HTTP 403 in this session. The accessible supplements contain clinical, sequencing and enrichment summaries, but no cell-level expression matrix. The sample-tag summaries have blank donor-name fields. No new blood expression result was calculated.

## Reproduce the external analysis

Python dependencies: numpy, pandas, scipy and matplotlib. Use the versions recorded in `environment.json` or compatible versions. The frozen input files are included.

```bash
python analyse_external_nerve.py --root .
python reconstruct_atlas_comparator.py --root .
python render_external_nerve.py --root . --output figures
```

The first command reads the deposited series matrix and the extracted GPL13369 annotation. It reproduces the complete sample mapping, probe audit, gene values, donor scores, primary result and sensitivity analyses. All observations are donors or biopsies, not probes or cells.

The second command uses the recovered `results/GSE285983_macrophage_Fc_counts.csv` to recompute atlas scores and comparisons. To repeat aggregation from the raw matrices, download the following public files into `inputs/`, move the existing aggregate count CSV aside, and rerun the command:

- https://ftp.ncbi.nlm.nih.gov/geo/series/GSE285nnn/GSE285983/suppl/GSE285983_RAW.tar
- https://ftp.ncbi.nlm.nih.gov/geo/series/GSE285nnn/GSE285983/suppl/GSE285983_metadata_all.csv.gz

Raw aggregation uses h5py when available. An included fallback calls an already installed HDF5 library, including the HDF5 library bundled with VTK. It does not implement a separate HDF5 parser. All source HDF5 filenames and checksums are recorded in the aggregate count CSV. The 1.43 GB raw archive is not duplicated in this compact package.

The third command generates Figure S9 in PNG, PDF and SVG formats and writes a separate source table for each panel.

Optional public availability audit:

```bash
python audit_blood_public.py --root .
```

This command requires pandas, openpyxl and xlrd for reading the publisher supplements. It makes ordinary requests to NODE and Europe PMC, inventories the public spreadsheets, and extracts only the published study codes and limited clinical fields. It does not infer donor identity from cell counts or sample tags.

## Inputs and provenance

- GSE213455: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE213455
- GPL13369: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GPL13369
- Associated article: Cerri et al., Frontiers in Oncology 2022, doi:10.3389/fonc.2022.974751.
- Original atlas: Heming et al., Nature Communications 2025, doi:10.1038/s41467-025-62964-8.
- Blood candidate: Li et al., Scientific Reports 2023, doi:10.1038/s41598-023-32427-5.

`analysis_plan.md` records the sequence of decisions. The external plan preceded examination of its target gene effects. The internal comparator addendum followed the external result but preceded examination of atlas VN expression. Neither is a preregistration.

`input_manifest.csv` records source URLs and checksums. `analysis_summary.json` and `atlas_comparator_summary.json` report the calculated results. `Data_availability_audit.csv` distinguishes completed analyses from inaccessible or unsuitable candidates. The previous PXD056286 quantification remains a usability assessment, not a positive or negative validation result.

Supplementary Data 3 is a convenient workbook of fixed analysis outputs. Statistical results are generated by the Python scripts and are not recomputed by changing workbook cells.
